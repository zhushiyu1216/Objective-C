//
//  main.m
//  Chapter2Exercise
//
//  Created by zhushiyu01 on 2020/10/26.
//

#import <Foundation/Foundation.h>
#import "Car.h"
#import "XYPoint.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        Car *car1 = [[Car alloc] init];
        car1.name = @"car1";
        car1.mode = @"中型";
        car1.color = @"red";
        [car1 start];
        [car1 run];
        [car1 stop];
        
        
        XYPoint *point = [[XYPoint alloc] init];
        point.x = 10;
        point.y = 15;
        [point print];
    }
    return 0;
}
