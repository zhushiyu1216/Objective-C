//
//  XYPoint.h
//  Chapter2Exercise
//
//  Created by zhushiyu01 on 2020/10/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface XYPoint : NSObject

@property int x, y;

- (void) print;

@end

NS_ASSUME_NONNULL_END
