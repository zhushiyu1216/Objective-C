//
//  Car.h
//  Chapter2Exercise
//
//  Created by zhushiyu01 on 2020/10/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Car : NSObject

- (NSString *) name;
- (void) setName: (NSString *) name;

- (NSString *) mode;
- (void) setMode: (NSString *) mode;

- (NSString *) color;
- (void) setColor: (NSString *) color;

/// 启动
- (void) start;

/// 跑
- (void) run;

/// 停
- (void) stop;
@end

NS_ASSUME_NONNULL_END
