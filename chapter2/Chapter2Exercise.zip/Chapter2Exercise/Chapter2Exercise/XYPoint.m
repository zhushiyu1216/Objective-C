//
//  XYPoint.m
//  Chapter2Exercise
//
//  Created by zhushiyu01 on 2020/10/26.
//

#import "XYPoint.h"

@implementation XYPoint

@synthesize x, y;

- (void) print {
    NSLog(@"point(%i, %i)", x, y);
}
@end
