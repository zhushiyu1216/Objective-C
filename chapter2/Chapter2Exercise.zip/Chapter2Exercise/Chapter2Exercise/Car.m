//
//  Car.m
//  Chapter2Exercise
//
//  Created by zhushiyu01 on 2020/10/26.
//

#import "Car.h"

@implementation Car
{
    NSString *_name;
    NSString *_mode;
    NSString *_color;
}

- (NSString *)name {
    return _name;
}

- (void)setName:(NSString *)name {
    _name = name;
}

- (NSString *)mode {
    return _mode;
}

- (void)setMode:(NSString *)mode {
    _mode = mode;
}

- (NSString *)color {
    return _color;
}

- (void)setColor:(NSString *)color {
    _color = color;
}

- (void)start {
    NSLog(@"car(%@, %@, %@) start!!!", _name, _mode, _color);
}

- (void)run {
    NSLog(@"car(%@, %@, %@) run!!!", _name, _mode, _color);
}

- (void)stop {
    NSLog(@"car(%@, %@, %@) stop!!!", _name, _mode, _color);
}
@end
