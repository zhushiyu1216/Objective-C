//
//  Fraction.m
//  FractionExample
//
//  Created by zhushiyu01 on 2020/10/25.
//

#import "Fraction.h"

/// <#Description#>
@implementation Fraction
{
    
    int _numerator; // 分子
    int _denominator;
}

- (int) numerator {
    return _numerator;
}

- (void) setNumerator: (int) numerator {
    _numerator = numerator;
}

- (int) denominator {
    return _denominator;
}

- (void) setDenominator: (int) denominator {
    _denominator = denominator;
}

- (void) print {
    NSLog(@"the fraction is %i/%i", _numerator, _denominator);
}

@end
