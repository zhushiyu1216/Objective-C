//
//  main.m
//  FractionExample
//
//  Created by zhushiyu01 on 2020/10/25.
//

#import <Foundation/Foundation.h>
#import "Fraction.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        Fraction *fraction;
//        fraction = [Fraction alloc];
//        fraction = [fraction init];
        
//        Fraction *fraction = [[Fraction alloc] init];
        
        Fraction *fraction = [Fraction new];
        
        
//        fraction.numerator = 1;
        [fraction setNumerator: 3];
        fraction.denominator = 4;
        
        [fraction print];
//        fraction.print;
    }
    return 0;
}
