//
//  Fraction.h
//  FractionExample
//
//  Created by zhushiyu01 on 2020/10/25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Fraction : NSObject

/// get 分子
- (int) numerator;

/// set 分子
/// @param numerator  分子
- (void) setNumerator: (int) numerator;


/// get 分母
- (int) denominator;

/// set 分母
/// @param denominator  分母
- (void) setDenominator: (int) denominator;


/// 打印输出
- (void) print;

@end

NS_ASSUME_NONNULL_END
