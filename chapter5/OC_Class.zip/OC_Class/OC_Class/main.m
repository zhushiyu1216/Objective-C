//
//  main.m
//  OC_Class
//
//  Created by zhushiyu01 on 2020/11/28.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Fraction.h"

void handle (int *b) {
    *b = 10;
}

void handle2 (Fraction *f2) {
    [f2 setNumerator: 3 andDenominator: 5];
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Person *person = [[Person alloc] init];
        [person setAge: 20];
//        person.age = 15;
        [person print];
        
        NSLog(@"person age = %i", [person age]);
        
        
        Fraction *f = [[Fraction alloc] init];
        [f setNumerator: 3 andDenominator: 5];
        [f print];
        
        [f set: 5 : 6];
        [f print];
        
        
        int a = 5;
        handle(&a);
        NSLog(@"a = %i", a);
        
        handle2(f);
        [f print];
    }
    return 0;
}


