//
//  Person.m
//  OC_Class
//
//  Created by zhushiyu01 on 2020/11/28.
//

#import "Person.h"

@implementation Person

//@synthesize age;

- (void)print {
    NSLog(@"age = %i", self.age);
}

@end
