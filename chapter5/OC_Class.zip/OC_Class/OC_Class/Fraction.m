//
//  Fraction.m
//  OC_Class
//
//  Created by zhushiyu01 on 2020/11/28.
//

#import "Fraction.h"

@implementation Fraction

@synthesize numerator, denominator;

- (void)setNumerator:(int)n andDenominator:(int)d {
    numerator = n;
    denominator = d;
}

- (void)set:(int)n :(int)d {
    numerator = n;
    denominator = d;
}

- (void)print {
    
    static int printCount = 0;
    printCount++;
    
    NSLog(@"fraction = %i / %i, printCount:%i", numerator, denominator, printCount);
}
@end
