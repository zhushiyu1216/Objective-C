//
//  Person.h
//  OC_Class
//
//  Created by zhushiyu01 on 2020/11/28.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject

@property int age;

- (void) print;

@end

NS_ASSUME_NONNULL_END
