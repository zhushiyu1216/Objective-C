//
//  Fraction.h
//  OC_Class
//
//  Created by zhushiyu01 on 2020/11/28.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Fraction : NSObject

@property int numerator, denominator;

- (void) setNumerator:(int)numerator andDenominator: (int) denominator;
- (void) set: (int) n : (int)d;
- (void) print;
@end

NS_ASSUME_NONNULL_END
