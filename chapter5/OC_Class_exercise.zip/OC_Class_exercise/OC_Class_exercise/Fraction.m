//
//  Fraction.m
//  OC_Class_exercise
//
//  Created by zhushiyu01 on 2020/11/28.
//

#import "Fraction.h"

@implementation Fraction

@synthesize numerator, denominator;

- (void)set:(int)n over:(int)d {
    numerator = n;
    denominator = d;
}

- (Fraction *)add:(Fraction *)f {
    
    int resultN = numerator * f.denominator + denominator * f.numerator;
    int resultD = denominator * f.denominator;
    
    Fraction *result = [[Fraction alloc] init];
    [result setNumerator:resultN];
    [result setDenominator: resultD];
    
    [result reduce];
    
    return result;
}

- (Fraction *)sub:(Fraction *)f {
    int resultN = numerator * f.denominator - denominator * f.numerator;
    int resultD = denominator * f.denominator;
    
    Fraction *result = [[Fraction alloc] init];
    [result setNumerator:resultN];
    [result setDenominator: resultD];
    
    [result reduce];
    
    return result;
}

- (Fraction *)multi:(Fraction *)f {
    
    int resultN = numerator * f.numerator;
    int resultD = denominator * f.denominator;
    
    Fraction *result = [[Fraction alloc] init];
    [result setNumerator:resultN];
    [result setDenominator: resultD];
    
    [result reduce];
    
    return result;
}

- (Fraction *)divide:(Fraction *)f {
    int resultN = numerator * f.denominator;
    int resultD = denominator * f.numerator;
    
    Fraction *result = [[Fraction alloc] init];
    [result setNumerator:resultN];
    [result setDenominator: resultD];
    
    [result reduce];
    
    return result;
}

- (void)print {
    NSLog(@"fraction = %i/%i", numerator, denominator);
}

- (void) reduce {
    
    int bigger = MAX(numerator, denominator);
    int less = MIN(numerator, denominator);

    while (true) {
        int mod = bigger % less;
        if (mod == 0) {
            break;
        } else {
            bigger = less;
            less = mod;
        }
    }
    
    numerator /= less;
    denominator /= less;
}

@end
