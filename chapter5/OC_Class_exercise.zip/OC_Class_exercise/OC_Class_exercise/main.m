//
//  main.m
//  OC_Class_exercise
//
//  Created by zhushiyu01 on 2020/11/28.
//

#import <Foundation/Foundation.h>
#import "Fraction.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Fraction *f = [[Fraction alloc] init];
        [f set:1 over:5];
        
        Fraction *f2 = [[Fraction alloc] init];
        [f2 set:2 over:5];
        
        Fraction *result = [f add: f2];
        [result print];
        
        [f set:4 over:5];
        [f2 set:3 over:4];
        result = [f sub: f2];
        [result print];
        
        result = [f multi: f2];
        [result print];
        
        result = [f divide: f2];
        [result print];
    }
    return 0;
}
