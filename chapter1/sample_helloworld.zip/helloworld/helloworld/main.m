//
//  main.m
//  helloworld
//
//  Created by zhushiyu01 on 2020/10/14.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World, Hello OC!");
        
        int sum;
        sum = 50 + 25;
        int temp = 100;
        NSLog(@"sum = %i, temp = %i", sum, temp);
        
        printf("sum = %i", sum);
        printf(" ----- temp = %i \n", temp);
        
        NSLog(@"\nIn Objective-C, lowercase letters ar significant.\nmain is where program execution begins.\nover!");
        
        int var1 = 97;
        int var2 = 15;
        sum = var1 + var2;
        NSLog(@"%i + %i = %i", var1, var2, sum);
    }
    return 0;
}
