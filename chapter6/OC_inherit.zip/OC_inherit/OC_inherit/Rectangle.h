//
//  Rectangle.h
//  OC_inherit
//
//  Created by zhushiyu01 on 2021/1/3.
//

#import <Foundation/Foundation.h>
#import "XYPoint.h"

NS_ASSUME_NONNULL_BEGIN

@interface Rectangle : NSObject

@property int width, height;
@property XYPoint *origin;

- (void) setWidth: (int) _w andHeight: (int) _h;
- (int) area;
- (int) perimeter;
@end

NS_ASSUME_NONNULL_END
