//
//  Rectangle.m
//  OC_inherit
//
//  Created by zhushiyu01 on 2021/1/3.
//

#import "Rectangle.h"

@implementation Rectangle

@synthesize width, height;
@synthesize origin = _origin;

- (void)setOrigin:(XYPoint *)inOrigin {
    if (_origin == NULL) {
        _origin = [[XYPoint alloc] init];
    }
    [_origin setX:inOrigin.x andY:inOrigin.y];
}

- (XYPoint *)origin {
    XYPoint *result = [[XYPoint alloc] init];
    [result setX:_origin.x andY:_origin.y];
    return result;
}

- (void)setWidth:(int)_w andHeight:(int)_h {
    width = _w;
    height = _h;
}

- (int)area {
    return width * height;
}

- (int)perimeter {
    return (width + height) * 2;
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"x=%i, y=%i, width=%i, height=%i", _origin.x, _origin.y, width, height];
}

@end
