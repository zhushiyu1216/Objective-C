//
//  ClassB.h
//  OC_inherit
//
//  Created by zhushiyu01 on 2021/1/3.
//

#import "ClassA.h"

NS_ASSUME_NONNULL_BEGIN

@interface ClassB : ClassA

- (void) printVar;
@end

NS_ASSUME_NONNULL_END
