//
//  Square.m
//  OC_inherit
//
//  Created by zhushiyu01 on 2021/1/3.
//

#import "Square.h"

@implementation Square

- (void)setSide:(int)side {
    [self setWidth:side andHeight:side];
}

- (int)side {
    return self.width;
}

@end
