//
//  main.m
//  OC_inherit
//
//  Created by zhushiyu01 on 2021/1/3.
//

#import <Foundation/Foundation.h>
#import "ClassB.h"
#import "Square.h"
#import "Rectangle.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        ClassB *b = [[ClassB alloc] init];
        [b initVar];
        [b printVar];
    
        Square *square = [[Square alloc] init];
        [square setSide: 10];
        NSLog(@"square area = %d", [square area]);
        NSLog(@"square perimeter = %d", [square perimeter]);
        
        Rectangle *rect = [[Rectangle alloc] init];
        [rect setWidth:200 andHeight:100];
        
        XYPoint *point = [[XYPoint alloc] init];
        [point setX:4 andY:5];
        rect.origin = point;
        NSLog(@"rect: %@", rect);
        
        [point setX:8 andY:10];
        NSLog(@"rect: %@", rect);
        
        XYPoint *p2 = rect.origin;
        [p2 setX:3 andY:6];
        NSLog(@"rect: %@", rect);
        
    }
    return 0;
}
