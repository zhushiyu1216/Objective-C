//
//  ClassB.m
//  OC_inherit
//
//  Created by zhushiyu01 on 2021/1/3.
//

#import "ClassB.h"

@implementation ClassB

- (void)initVar {
    x = 200;
}
- (void)printVar {
    NSLog(@"x = %d", x);
//    NSLog(@"y = %d", y);
}
@end
