//
//  ClassA.m
//  OC_inherit
//
//  Created by zhushiyu01 on 2021/1/3.
//

#import "ClassA.h"

@implementation ClassA
{
    int y;
}

- (void)initVar {
    x = 100;
    y = 200;
}

@end
