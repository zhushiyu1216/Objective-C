//
//  ClassA.h
//  OC_inherit
//
//  Created by zhushiyu01 on 2021/1/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ClassA : NSObject
{
    int x;
}

- (void) initVar;

@end

NS_ASSUME_NONNULL_END
