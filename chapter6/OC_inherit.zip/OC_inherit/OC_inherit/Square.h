//
//  Square.h
//  OC_inherit
//
//  Created by zhushiyu01 on 2021/1/3.
//

#import "Rectangle.h"

NS_ASSUME_NONNULL_BEGIN

@interface Square : Rectangle

- (void) setSide: (int) side;

- (int) side;

@end

NS_ASSUME_NONNULL_END
