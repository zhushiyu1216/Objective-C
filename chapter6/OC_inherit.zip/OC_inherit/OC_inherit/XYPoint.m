//
//  XYPoint.m
//  OC_inherit
//
//  Created by zhushiyu01 on 2021/1/3.
//

#import "XYPoint.h"

@implementation XYPoint

@synthesize x, y;

- (void)setX:(int)_x andY:(int)_y {
    x = _x;
    y = _y;
}

@end
