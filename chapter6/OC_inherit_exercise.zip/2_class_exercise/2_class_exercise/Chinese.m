//
//  Chinese.m
//  2_class_exercise
//
//  Created by zhushiyu01 on 2021/1/27.
//

#import "Chinese.h"

@implementation Chinese

- (void)writeHanzi {
    
}
@end
