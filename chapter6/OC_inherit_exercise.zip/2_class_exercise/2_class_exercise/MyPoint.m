//
//  MyPoint.m
//  2_class_exercise
//
//  Created by zhushiyu01 on 2021/1/27.
//

#import "MyPoint.h"

@implementation MyPoint

@synthesize x, y;

- (instancetype)initX:(int)_x andY:(int)_y {
    self = [super init];
    if (self) {
        self.x = _x;
        self.y = _y;
    }
    
    return self;
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"(%i, %i)", x, y];
}

@end
