//
//  Rectangle.h
//  2_class_exercise
//
//  Created by zhushiyu01 on 2021/1/27.
//

#import <Foundation/Foundation.h>
#import "MyPoint.h"

NS_ASSUME_NONNULL_BEGIN

@interface Rectangle : NSObject

@property MyPoint *origin;
@property int width, height;

- (instancetype) initOrigin: (MyPoint *)o andWidth: (int) w andHeight: (int) h;

- (Rectangle *) intersect: (Rectangle *) inRect;

- (void) draw;

@end

NS_ASSUME_NONNULL_END
