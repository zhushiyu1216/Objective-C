//
//  Animal.m
//  2_class_exercise
//
//  Created by zhushiyu01 on 2021/1/27.
//

#import "Animal.h"

@implementation Animal

@synthesize weight;

- (void)breath {
    NSLog(@"animal breath");
}
@end
