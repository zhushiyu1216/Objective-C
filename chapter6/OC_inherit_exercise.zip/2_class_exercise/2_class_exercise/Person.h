//
//  Person.h
//  2_class_exercise
//
//  Created by zhushiyu01 on 2021/1/27.
//

#import "Animal.h"

NS_ASSUME_NONNULL_BEGIN

@interface Person : Animal

@property int heigh;

- (void) say;

@end

NS_ASSUME_NONNULL_END
