//
//  Rectangle.m
//  2_class_exercise
//
//  Created by zhushiyu01 on 2021/1/27.
//

#import "Rectangle.h"

@implementation Rectangle

@synthesize origin, width, height;

- (instancetype)initOrigin:(MyPoint *)o andWidth:(int)w andHeight:(int)h {
    self = [super init];
    if (self) {
        self.origin = [[MyPoint alloc] initX: o.x andY: o.y];
        self.width = w;
        self.height = h;
    }
    
    return self;
}

- (Rectangle *)intersect:(Rectangle *)inRect {
    
    int x1 = MAX(origin.x, inRect.origin.x);
    int y1 = MAX(origin.y, inRect.origin.y);
    
    int x2 = MIN(origin.x + width, inRect.origin.x + inRect.width);
    int y3 = MIN(origin.y + height, inRect.origin.y + inRect.height);
    
    return [[Rectangle alloc] initOrigin:[[MyPoint alloc] initX:x1 andY:y1] andWidth:x2 - x1 andHeight:y3 - y1];
}

- (void)draw {
    for (int hi = 0; hi < height + 2; hi++) {
        for (int wj = 0; wj < width; wj++) {
            if (hi == 0 || hi == height + 1) {
                printf("-");
            } else {
                if (wj == 0 || wj == width - 1) {
                    printf("|");
                } else {
                    printf(" ");
                }
            }
        }
        printf("\n");
    }
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"[%@, %i, %i]", origin, width, height];
}

@end
