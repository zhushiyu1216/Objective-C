//
//  main.m
//  2_class_exercise
//
//  Created by zhushiyu01 on 2021/1/27.
//

#import <Foundation/Foundation.h>
#import "Chinese.h"
#import "Rectangle.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        
        Chinese *chinese = [[Chinese alloc] init];
        [chinese breath];
        
        Rectangle *rect1 = [[Rectangle alloc] initOrigin: [[MyPoint alloc] initX:5 andY:5] andWidth:20 andHeight:10];
        Rectangle *rect2 = [[Rectangle alloc] initOrigin: [[MyPoint alloc] initX:7 andY:7] andWidth:20 andHeight:10];
        
        NSLog(@"result: %@", [rect1 intersect: rect2]);
        
        Rectangle *rect3 = [[Rectangle alloc] initOrigin: [[MyPoint alloc] initX:0 andY:0] andWidth:5 andHeight:4];
        [rect3 draw];
    }
    return 0;
}
