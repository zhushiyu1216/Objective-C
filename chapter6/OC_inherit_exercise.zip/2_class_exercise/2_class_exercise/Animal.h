//
//  Animal.h
//  2_class_exercise
//
//  Created by zhushiyu01 on 2021/1/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Animal : NSObject

@property float weight;

- (void) breath;

@end

NS_ASSUME_NONNULL_END
