//
//  Person.m
//  2_class_exercise
//
//  Created by zhushiyu01 on 2021/1/27.
//

#import "Person.h"

@implementation Person

@synthesize heigh;

- (void)say {
    
}

@end
