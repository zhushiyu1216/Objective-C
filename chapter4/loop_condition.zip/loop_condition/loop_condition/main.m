//
//  main.m
//  loop_condition
//
//  Created by zhushiyu01 on 2020/11/16.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        
        int number1, number2;
        NSLog(@"number1:");
        scanf("%i", &number1);
        NSLog(@"number2:");
        scanf("%i", &number2);
        
        if (number1 < 5 || 15 < number1) {
            
        }
        
        int big = MAX(number1, number2);
        int little = MIN(number1, number2);
        while (YES) {
            int mod = big % little;
            if (mod == 0) {
                break;
            } else {
                big = little;
                little = mod;
            }
        }
        NSLog(@"最大公约数是：%i", little);
        
        
    }
    return 0;
}
