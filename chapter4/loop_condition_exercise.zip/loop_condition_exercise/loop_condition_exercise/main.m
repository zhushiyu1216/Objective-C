//
//  main.m
//  loop_condition_exercise
//
//  Created by zhushiyu01 on 2020/11/17.
//

#import <Foundation/Foundation.h>
#import "MultiplySample.h"
#import "Calculator.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        MultiplySample *multiply = [[MultiplySample alloc] init];
        [multiply show];
        [multiply showWithWhile];
        
        Calculator *calculator = [[Calculator alloc] init];
        [calculator start];
    }
    return 0;
}
