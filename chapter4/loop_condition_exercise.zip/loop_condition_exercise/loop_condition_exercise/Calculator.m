//
//  Calculator.m
//  loop_condition_exercise
//
//  Created by zhushiyu01 on 2020/11/17.
//

#import "Calculator.h"

@implementation Calculator

- (void)start {
    float result = 0;
    
    NSLog(@"please input a number:");
    scanf("%f", &result);
    
    while (true) {
        NSLog(@"please input operator, '+ - x / =', :");
        char operator;
        scanf(" %c", &operator);
        if (operator == '='){
            break;
        } else if (operator != '+' && operator != '-' && operator != 'x' && operator != '/') {
            NSLog(@"operator not support: %c", operator);
            continue;
        }
        
        NSLog(@"please input a number:");
        float number;
        scanf("%f", &number);
        if (operator == '+') {
            result += number;
        } else if (operator == '-') {
            result -= number;
        } else if (operator == 'x') {
            result *= number;
        } else if (operator == '/') {
            result /= number;
        }
    }
    NSLog(@"result is : %g", result);
}

@end
