//
//  MultiplySample.h
//  loop_condition_exercise
//
//  Created by zhushiyu01 on 2020/11/17.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MultiplySample : NSObject

- (void) show;

- (void) showWithWhile;

@end

NS_ASSUME_NONNULL_END
