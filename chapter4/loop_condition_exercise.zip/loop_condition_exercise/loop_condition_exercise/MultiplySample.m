//
//  MultiplySample.m
//  loop_condition_exercise
//
//  Created by zhushiyu01 on 2020/11/17.
//

#import "MultiplySample.h"

@implementation MultiplySample


- (void)show {
    for (int i = 10; i > 0; i--) {
        int result = i;
        printf("%i ", i);
        for (int j = i - 1; j > 0; j--) {
            result *= j;
            printf("x %i ", j);
        }
        printf(" = %i\n", result);
    }
}

- (void)showWithWhile {
    int i = 10;
    while (i > 0) {
        int result = i;
        printf("%i ", i);
        int j = i - 1;
        while (j > 0) {
            result *= j;
            printf("x %i ", j);
            j--;
        }
        printf(" = %i\n", result);
        i--;
    }
}
@end
