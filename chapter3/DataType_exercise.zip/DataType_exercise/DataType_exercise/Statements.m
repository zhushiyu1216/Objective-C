//
//  Statements.m
//  DataType_exercise
//
//  Created by zhushiyu01 on 2020/10/31.
//

#import "Statements.h"

@implementation Statements

- (double)statement1:(double)x {
//    return 3 * (x * x * x) - 5 * (x * x) + 6;
    return 3 * pow(x, 3) - 5 * pow(x, 2) + 6;
}
@end
