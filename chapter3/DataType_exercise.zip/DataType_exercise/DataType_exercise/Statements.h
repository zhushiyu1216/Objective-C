//
//  Statements.h
//  DataType_exercise
//
//  Created by zhushiyu01 on 2020/10/31.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Statements : NSObject

- (double) statement1: (double) x;

@end

NS_ASSUME_NONNULL_END
