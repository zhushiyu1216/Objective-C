//
//  main.m
//  DataType_exercise
//
//  Created by zhushiyu01 on 2020/10/31.
//

#import <Foundation/Foundation.h>
#import "Statements.h"
#import "Rectangle.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Statements *s = [[Statements alloc] init];
        
        double x = 5.55;
        double result = [s statement1: x];
        NSLog(@"result = %g", result);
        
        double r2 = (3.31 * pow(10, -8) + 2.01 * pow(10, -7)) / (7.16 * pow(10, -6) + 2.01 * pow(10, -8));
        NSLog(@"r2 = %g", r2);
        
        Rectangle *rect = [[Rectangle alloc] init];
        rect.width = 124.5;
        rect.height = 18.6;
        NSLog(@"rect's perimeter = %.2f, area = %.2f", [rect perimeter], [rect area]);
    }
    return 0;
}
