//
//  Rectangle.m
//  DataType_exercise
//
//  Created by zhushiyu01 on 2020/10/31.
//

#import "Rectangle.h"

@implementation Rectangle

@synthesize width, height;

- (float)perimeter {
    return 2 * (width + height);
}

- (float)area {
    return width * height;
}
@end
