//
//  Rectangle.h
//  DataType_exercise
//
//  Created by zhushiyu01 on 2020/10/31.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Rectangle : NSObject

/// 宽和高
@property float width, height;

/// 周长
- (float) perimeter;

/// 面积
- (float) area;
@end

NS_ASSUME_NONNULL_END
