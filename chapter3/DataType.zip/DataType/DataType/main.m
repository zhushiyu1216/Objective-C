//
//  main.m
//  DataType
//
//  Created by zhushiyu01 on 2020/10/31.
//

#import <Foundation/Foundation.h>
#import "Test1.h"
#import "Calculator.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int i = 10;
        NSLog(@"i = %i", i);
        
        float f = 331.79;
        NSLog(@"f = %.2f", f);
        
        double d = 13.244566;
        NSLog(@"d = %f", d);
        
        char c = 'a';
        char *str = "abcdef";
        NSString *str2 = @"nsstring";
        NSLog(@"c = %c, str = %s, str2 = %@", c, str, str2);
        
        BOOL b = YES;
        b = NO;
        if (b) {
          NSLog(@"...");
        }

        if (!b) {
          NSLog(@"b = %@", b ? @"YES" : @"NO");
        }
        
        Test1 *t1 = [[Test1 alloc] init];
        NSLog(@"t1 = %@", t1);
        
        id t2 = [[Test1 alloc] init];
        NSLog(@"t2 = %@", t2);
        
        
        float f1 = 123.2;
        float f2;
        int i1, i2 = -150;

        i1 = f1; // 浮点数123.2被截断转为123
        NSLog(@"i1 = %i", i1);
        f2 = 123;
        f2 = i2 / 100.0;
        NSLog(@"f2 = %f", f2);
        
        int a = (int) 29.55 + (int) 21.99;
        NSLog(@"a= %i", a);
        
        
        Calculator *cal = [[Calculator alloc] init];
        cal.accumulator = 0;
        [cal add: 200.];
        [cal divide: 15.5];
        [cal subtract: 10.3];
        [cal multiply: 5];

        NSLog(@"the result is %g", cal.accumulator);

        [cal clear];
        [cal add: 30.5];
        NSLog(@"the result is %g", cal.accumulator);
    }
    return 0;
}
