//
//  Calculator.h
//  DataType
//
//  Created by zhushiyu01 on 2020/10/31.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Calculator : NSObject

@property double accumulator;

- (void) clear;

- (void) add: (double) value;
- (void) subtract: (double) value;
- (void) multiply: (double) value;
- (void) divide: (double) value;

@end

NS_ASSUME_NONNULL_END
