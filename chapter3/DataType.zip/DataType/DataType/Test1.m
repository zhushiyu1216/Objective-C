//
//  Test1.m
//  DataType
//
//  Created by zhushiyu01 on 2020/10/31.
//

#import "Test1.h"

@implementation Test1

- (NSString *)description
{
    return [NSString stringWithFormat:@"test1 abdef"];
}
@end
