//
//  Calculator.m
//  DataType
//
//  Created by zhushiyu01 on 2020/10/31.
//

#import "Calculator.h"

@implementation Calculator

@synthesize accumulator;

- (void)clear {
    accumulator = 0;
}

- (void)add:(double)value {
    accumulator = accumulator + value;
}

- (void)subtract:(double)value {
    accumulator -= value;
}

- (void)multiply:(double)value {
    accumulator *= value;
}

- (void)divide:(double)value {
    accumulator = accumulator / value;
}

@end
